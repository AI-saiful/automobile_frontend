const original_domain = "http://192.168.0.107:8000"

export const BACKEND_URL = `${original_domain}/automobile/`



